import { describe, expect, it } from "vitest";
import { detectGhostResolution } from "./db";

describe("ghost resolution detector", () => {
  it("flags a complaint after repeated resolution attempts", () => {
    expect(detectGhostResolution(2, 0)).toBe(1);
    expect(detectGhostResolution(0, 2)).toBe(1);
  });

  it("flags a resolved complaint that is reopened", () => {
    expect(detectGhostResolution(1, 1)).toBe(1);
  });

  it("preserves an existing flag and leaves clean records unflagged", () => {
    expect(detectGhostResolution(0, 0, 1)).toBe(1);
    expect(detectGhostResolution(1, 0, 0)).toBe(0);
    expect(detectGhostResolution(0, 1, 0)).toBe(0);
  });
});
