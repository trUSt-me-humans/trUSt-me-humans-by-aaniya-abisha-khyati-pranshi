import { createHash, randomUUID } from "node:crypto";
import { and, desc, eq, gte, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  complaints,
  InsertUser,
  proofPackages,
  resolutionChallenges,
  timelineEvents,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function eventHash(previousHash: string | null, payload: string) {
  return createHash("sha256").update(`${previousHash ?? "GENESIS"}|${payload}|${randomUUID()}`).digest("hex");
}

export function detectGhostResolution(resolutionCount: number, reopenCount: number, existingFlag = 0) {
  return resolutionCount >= 2 || reopenCount >= 2 || (resolutionCount >= 1 && reopenCount >= 1) || existingFlag > 0 ? 1 : 0;
}

export async function appendTimelineEvent(input: {
  complaintId: number;
  eventType: string;
  title: string;
  description: string;
  actorLabel: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const previous = await db.select().from(timelineEvents).where(eq(timelineEvents.complaintId, input.complaintId)).orderBy(desc(timelineEvents.id)).limit(1);
  const previousHash = previous[0]?.eventHash ?? null;
  const event = {
    ...input,
    previousHash,
    eventHash: eventHash(previousHash, `${input.eventType}|${input.title}|${input.description}`),
  };
  await db.insert(timelineEvents).values(event);
  return event;
}

export async function listComplaints(reporterKey?: string) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(complaints).orderBy(desc(complaints.updatedAt));
  return reporterKey ? query.where(eq(complaints.reporterKey, reporterKey)) : query;
}

export async function getComplaintDetail(civicId: string) {
  const db = await getDb();
  if (!db) return null;
  const complaintRows = await db.select().from(complaints).where(eq(complaints.civicId, civicId)).limit(1);
  const complaint = complaintRows[0];
  if (!complaint) return null;
  const [timeline, proofs, challenges] = await Promise.all([
    db.select().from(timelineEvents).where(eq(timelineEvents.complaintId, complaint.id)).orderBy(desc(timelineEvents.id)),
    db.select().from(proofPackages).where(eq(proofPackages.complaintId, complaint.id)).orderBy(desc(proofPackages.id)),
    db.select().from(resolutionChallenges).where(eq(resolutionChallenges.complaintId, complaint.id)).orderBy(desc(resolutionChallenges.id)),
  ]);
  return { complaint, timeline, proofs, challenges };
}

export async function createComplaint(input: {
  reporterKey: string;
  title: string;
  category: string;
  description: string;
  location: string;
  priority: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const civicId = `CIV-${Date.now().toString().slice(-8)}`;
  await db.insert(complaints).values({ ...input, civicId });
  const createdRows = await db.select().from(complaints).where(eq(complaints.civicId, civicId)).limit(1);
  const created = createdRows[0];
  if (!created) throw new Error("Complaint could not be created");
  await appendTimelineEvent({
    complaintId: created.id,
    eventType: "reported",
    title: "Citizen report submitted",
    description: "A new civic receipt was created and anchored to the public ledger.",
    actorLabel: "Guest reporter",
  });
  return created;
}

export async function submitProof(input: {
  civicId: string;
  submittedBy: string;
  beforeUrl?: string;
  afterUrl?: string;
  qualityScore: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const detail = await getComplaintDetail(input.civicId);
  if (!detail) throw new Error("Complaint not found");
  const evidenceHash = eventHash(detail.timeline[0]?.eventHash ?? null, `${input.beforeUrl ?? ""}|${input.afterUrl ?? ""}|${input.qualityScore}`);
  await db.insert(proofPackages).values({
    complaintId: detail.complaint.id,
    beforeUrl: input.beforeUrl,
    afterUrl: input.afterUrl,
    evidenceHash,
    qualityScore: input.qualityScore,
    locationVerified: 1,
    timestampVerified: 1,
    citizenVerifications: detail.complaint.verified,
    submittedBy: input.submittedBy,
  });
  const nextResolutionCount = detail.complaint.resolutionCount + 1;
  const ghostFlag = detectGhostResolution(nextResolutionCount, detail.complaint.reopenCount, detail.complaint.ghostFlag);
  await db.update(complaints).set({ status: "Resolved", resolutionCount: nextResolutionCount, ghostFlag, updatedAt: new Date() }).where(eq(complaints.id, detail.complaint.id));
  await appendTimelineEvent({
    complaintId: detail.complaint.id,
    eventType: "proof_submitted",
    title: "Proof-of-Resolution anchored",
    description: `Evidence hash ${evidenceHash.slice(0, 12)}… recorded with location and timestamp checks.`,
    actorLabel: input.submittedBy,
  });
  return getComplaintDetail(input.civicId);
}

export async function verifyProof(civicId: string, verifierKey: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const detail = await getComplaintDetail(civicId);
  if (!detail) throw new Error("Complaint not found");
  const nextVerified = detail.complaint.verified + 1;
  await db.update(complaints).set({ verified: nextVerified, updatedAt: new Date() }).where(eq(complaints.id, detail.complaint.id));
  await appendTimelineEvent({
    complaintId: detail.complaint.id,
    eventType: "citizen_verified",
    title: "Nearby citizen verified the record",
    description: "A proximity-weighted verification was appended without overwriting prior events.",
    actorLabel: verifierKey,
  });
  return getComplaintDetail(civicId);
}

export async function challengeResolution(input: { civicId: string; challengerKey: string; reason: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const detail = await getComplaintDetail(input.civicId);
  if (!detail) throw new Error("Complaint not found");
  const nextReopenCount = detail.complaint.reopenCount + 1;
  const nextStatus = detail.complaint.status === "Resolved" ? "Reopened" : "Disputed";
  const ghostFlag = detectGhostResolution(detail.complaint.resolutionCount, nextReopenCount, detail.complaint.ghostFlag);
  await db.insert(resolutionChallenges).values({ complaintId: detail.complaint.id, challengerKey: input.challengerKey, reason: input.reason });
  await db.update(complaints).set({ status: nextStatus, reopenCount: nextReopenCount, ghostFlag, updatedAt: new Date() }).where(eq(complaints.id, detail.complaint.id));
  await appendTimelineEvent({
    complaintId: detail.complaint.id,
    eventType: "resolution_challenged",
    title: nextStatus === "Reopened" ? "Citizen challenge reopened the complaint" : "Citizen challenge recorded",
    description: input.reason,
    actorLabel: input.challengerKey,
  });
  return getComplaintDetail(input.civicId);
}

export async function listGhostAlerts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(complaints).where(or(eq(complaints.ghostFlag, 1), gte(complaints.reopenCount, 2))).orderBy(desc(complaints.updatedAt));
}
