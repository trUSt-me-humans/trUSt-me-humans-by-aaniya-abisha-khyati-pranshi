import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  challengeResolution,
  createComplaint,
  getComplaintDetail,
  listComplaints,
  listGhostAlerts,
  submitProof,
  verifyProof,
} from "./db";

const reporterSchema = z.object({ reporterKey: z.string().min(3).max(128).default("guest-browser") });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  complaints: router({
    list: publicProcedure.input(reporterSchema.extend({ mineOnly: z.boolean().default(false) })).query(({ input, ctx }) => {
      const key = ctx.user?.openId ?? input.reporterKey;
      return listComplaints(input.mineOnly ? key : undefined);
    }),
    live: publicProcedure.query(() => listComplaints()),
    detail: publicProcedure.input(z.object({ civicId: z.string() })).query(({ input }) => getComplaintDetail(input.civicId)),
    create: publicProcedure.input(z.object({
      reporterKey: z.string().min(3).max(128).default("guest-browser"),
      title: z.string().min(3).max(180),
      category: z.string().min(2).max(64),
      description: z.string().min(5),
      location: z.string().min(2).max(255),
      priority: z.number().int().min(1).max(100).default(50),
    })).mutation(({ input, ctx }) => createComplaint({ ...input, reporterKey: ctx.user?.openId ?? input.reporterKey })),
    challenge: publicProcedure.input(z.object({
      civicId: z.string(),
      challengerKey: z.string().min(3).max(128).default("guest-browser"),
      reason: z.string().min(5).max(1000),
    })).mutation(({ input, ctx }) => challengeResolution({ ...input, challengerKey: ctx.user?.openId ?? input.challengerKey })),
    verify: publicProcedure.input(z.object({ civicId: z.string(), verifierKey: z.string().min(3).max(128).default("guest-verifier") })).mutation(({ input, ctx }) => verifyProof(input.civicId, ctx.user?.openId ?? input.verifierKey)),
    proof: router({
      submit: publicProcedure.input(z.object({
        civicId: z.string(),
        submittedBy: z.string().min(3).max(128).default("department-demo"),
        beforeUrl: z.string().optional(),
        afterUrl: z.string().optional(),
        qualityScore: z.number().int().min(0).max(100).default(88),
      })).mutation(({ input, ctx }) => submitProof({ ...input, submittedBy: ctx.user?.openId ?? input.submittedBy })),
    }),
    ghosts: publicProcedure.query(() => listGhostAlerts()),
  }),
});

export type AppRouter = typeof appRouter;
