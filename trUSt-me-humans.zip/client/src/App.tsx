import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";

export default function App() {
  // make sure to consider if you need authentication for certain routes
  return (
    <TooltipProvider>
      <Toaster position="top-right" theme="dark" />
      <Home />
    </TooltipProvider>
  );
}
