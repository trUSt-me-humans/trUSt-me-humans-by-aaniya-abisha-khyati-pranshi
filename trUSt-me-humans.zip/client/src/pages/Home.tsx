import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  BarChart3,
  Bell,
  Blocks,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Crosshair,
  FileCheck2,
  Filter,
  Flag,
  Gauge,
  GitBranch,
  Info,
  LayoutDashboard,
  ListFilter,
  MapPinned,
  Menu,
  MessageSquareWarning,
  MoreHorizontal,
  Plus,
  Radio,
  RotateCcw,
  Search,
  ShieldCheck,
  Sparkles,
  Timer,
  TrendingUp,
  UsersRound,
  X,
  Zap,
} from "lucide-react";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

type Status = "Open" | "Under review" | "Resolved" | "Disputed" | "Reopened";

type Incident = {
  id: string;
  title: string;
  location: string;
  category: string;
  status: Status;
  age: string;
  reports: number;
  priority: number;
  verified: number;
  color: string;
  accent: string;
};

const incidents: Incident[] = [
  { id: "CIV-82914", title: "Deep pothole on School Road", location: "Sector 14 · Ward 23", category: "Roads", status: "Under review", age: "18 min ago", reports: 27, priority: 94, verified: 8, color: "#ffb86b", accent: "amber" },
  { id: "CIV-82887", title: "Streetlight outage cluster", location: "Moti Bagh · Ward 08", category: "Lighting", status: "Open", age: "41 min ago", reports: 14, priority: 81, verified: 0, color: "#ff7b8e", accent: "coral" },
  { id: "CIV-82861", title: "Overflowing bins near market", location: "Green Park · Ward 11", category: "Sanitation", status: "Resolved", age: "2 hrs ago", reports: 19, priority: 63, verified: 17, color: "#82e6c2", accent: "mint" },
  { id: "CIV-82805", title: "Water leak at community gate", location: "Vasant Kunj · Ward 18", category: "Water", status: "Disputed", age: "4 hrs ago", reports: 11, priority: 76, verified: 4, color: "#96c8ff", accent: "blue" },
  { id: "CIV-82744", title: "Unsafe crossing by metro exit", location: "Hauz Khas · Ward 05", category: "Safety", status: "Resolved", age: "Yesterday", reports: 31, priority: 88, verified: 25, color: "#82e6c2", accent: "mint" },
];

const timeline = [
  { time: "13 Sep · 11:42", icon: MessageSquareWarning, title: "Citizen report submitted", body: "Pseudonymous resident ID #A82F attached photo evidence.", tone: "coral" },
  { time: "13 Sep · 11:44", icon: Blocks, title: "Record anchored on Civic Ledger", body: "Hash 0x8f…92a recorded. Personal data stays off-chain.", tone: "mint" },
  { time: "13 Sep · 12:03", icon: GitBranch, title: "Assigned to PWD · Ward 23", body: "Service-level clock started with a 24 hour response target.", tone: "amber" },
  { time: "13 Sep · 12:21", icon: UsersRound, title: "8 nearby citizens verified", body: "Proximity-weighted confirmations increased incident priority.", tone: "blue" },
];

const statusOptions: Array<"All" | Status> = ["All", "Open", "Under review", "Resolved", "Disputed"];

type Hotspot = { city: string; state: string; category: string; reports: number; severity: string; status: Status; lat: number; lng: number; left: string; top: string; tone: string };
const hotspots: Hotspot[] = [
  { city: "New Delhi", state: "Delhi", category: "Roads & lighting", reports: 42, severity: "High", status: "Under review", lat: 28.61, lng: 77.21, left: "49%", top: "28%", tone: "hot" },
  { city: "Mumbai", state: "Maharashtra", category: "Water & sanitation", reports: 68, severity: "Critical", status: "Open", lat: 19.07, lng: 72.87, left: "30%", top: "57%", tone: "critical" },
  { city: "Bengaluru", state: "Karnataka", category: "Roads", reports: 36, severity: "Medium", status: "Resolved", lat: 12.97, lng: 77.59, left: "42%", top: "75%", tone: "warm" },
  { city: "Kolkata", state: "West Bengal", category: "Drainage", reports: 51, severity: "High", status: "Under review", lat: 22.57, lng: 88.36, left: "73%", top: "39%", tone: "hot" },
  { city: "Hyderabad", state: "Telangana", category: "Streetlights", reports: 24, severity: "Medium", status: "Open", lat: 17.38, lng: 78.49, left: "52%", top: "58%", tone: "warm" },
  { city: "Chennai", state: "Tamil Nadu", category: "Flooding", reports: 45, severity: "High", status: "Disputed", lat: 13.08, lng: 80.27, left: "57%", top: "82%", tone: "hot" },
];
const trustFactors = [
  ["Verified reports", 24, "24 of 29 reports confirmed by nearby residents"],
  ["Completed audits", 18, "18 ward-level checks closed this quarter"],
  ["Resolution transparency", 17, "Proof attached to 82% of resolved issues"],
  ["Community confirmations", 14, "146 proximity-weighted confirmations"],
  ["Evidence quality", 9, "Photos, timestamps, and location checks"],
] as const;
const auditEvents = [
  ["09:42", "Citizen report submitted", "Resident · pseudonymous ID #A82F", "VERIFIED"],
  ["09:44", "AI classification completed", "Civic classifier · Roads / priority 94", "VERIFIED"],
  ["10:02", "Department assigned", "PWD · Ward 23 desk", "VERIFIED"],
  ["11:18", "Action initiated", "Field crew · School Road", "IN PROGRESS"],
  ["12:21", "Evidence uploaded", "PWD · before/after photo package", "VERIFIED"],
  ["12:34", "Community verification", "8 nearby citizens", "VERIFIED"],
] as const;
const networkServices = [
  ["Core network", "ONLINE", "99.98% heartbeat · demo status"],
  ["API status", "ONLINE", "tRPC gateway responding in 184ms"],
  ["Database", "ONLINE", "Ledger sync completed 12s ago"],
  ["Map service", "ONLINE", "India tiles and hotspot layer loaded"],
] as const;
function getInitials(name?: string | null) {
  const parts = (name ?? "Guest").trim().split(/[\s._-]+/).filter(Boolean);
  if (parts.length === 0) return "G";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}

function StatusPill({ status }: { status: Status }) {
  const styles: Record<Status, string> = {
    Open: "status-open",
    "Under review": "status-review",
    Resolved: "status-resolved",
    Disputed: "status-disputed",
    Reopened: "status-disputed",
  };
  return <span className={`status-pill ${styles[status]}`}><span className="status-dot" />{status}</span>;
}

function MetricCard({ label, value, delta, icon: Icon, tone }: { label: string; value: string; delta: string; icon: typeof Activity; tone: string }) {
  return (
    <div className="metric-card">
      <div className="metric-top"><span>{label}</span><span className={`metric-icon ${tone}`}><Icon size={16} /></span></div>
      <div className="metric-value">{value}</div>
      <div className="metric-delta"><TrendingUp size={13} /> {delta}</div>
    </div>
  );
}

export default function Home() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const profileName = user?.name ?? user?.email?.split("@")[0] ?? "Guest";
  const profileInitials = getInitials(user?.name ?? user?.email);
  const [introStage, setIntroStage] = useState<"logo" | "exit">("logo");
  const [pageReady, setPageReady] = useState(false);
  const [activeNav, setActiveNav] = useState("Command center");
  const [filter, setFilter] = useState<"All" | Status>("All");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState("CIV-82914");
  const [showReport, setShowReport] = useState(false);
  const [showFullMap, setShowFullMap] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("All categories");
  const [imageName, setImageName] = useState("");
  const [challengeSent, setChallengeSent] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedHotspot, setSelectedHotspot] = useState<Hotspot>(hotspots[0]);
  useEffect(() => {
    if (!authLoading && !isAuthenticated) setShowLogin(true);
    if (isAuthenticated) setShowLogin(false);
  }, [authLoading, isAuthenticated]);
  const [reportCategory, setReportCategory] = useState("Roads");
  const [reportLocation, setReportLocation] = useState("Sector 14, School Road");
  const [reportDescription, setReportDescription] = useState("Deep pothole across the left lane near the school gate.");
  const [reporterKey] = useState(() => `guest-${Math.random().toString(36).slice(2, 10)}`);
  const liveQuery = trpc.complaints.live.useQuery(undefined, { refetchInterval: 10000 });
  const mineQuery = trpc.complaints.list.useQuery({ reporterKey, mineOnly: true }, { refetchInterval: 10000 });
  const ghostQuery = trpc.complaints.ghosts.useQuery(undefined, { refetchInterval: 10000 });
  const utils = trpc.useUtils();
  const createComplaintMutation = trpc.complaints.create.useMutation({
    onSuccess: (complaint) => {
      setShowReport(false);
      setSelectedId(complaint.civicId);
      void utils.complaints.invalidate();
      toast.success("Civic receipt created", { description: `${complaint.civicId} is now visible in My complaints.` });
    },
    onError: (error) => toast.error("Could not create complaint", { description: error.message }),
  });
  const challengeMutation = trpc.complaints.challenge.useMutation({
    onSuccess: () => {
      setChallengeSent(true);
      void utils.complaints.invalidate();
      toast.success("Challenge recorded", { description: `${selectedId} was appended to the immutable timeline.` });
    },
    onError: (error) => toast.error("Could not record challenge", { description: error.message }),
  });
  const selectedDetailQuery = trpc.complaints.detail.useQuery({ civicId: selectedId }, { refetchInterval: 10000 });
  const proofMutation = trpc.complaints.proof.submit.useMutation({
    onSuccess: () => {
      void utils.complaints.invalidate();
      toast.success("Proof-of-Resolution anchored", { description: "The evidence package and hash are now part of the immutable record." });
    },
    onError: (error) => toast.error("Could not anchor proof", { description: error.message }),
  });

  const allIncidents = useMemo(() => {
    const persisted = (liveQuery.data ?? []).map((item) => ({
      id: item.civicId,
      title: item.title,
      location: item.location,
      category: item.category,
      status: item.status as Status,
      age: new Date(item.updatedAt).toLocaleDateString(),
      reports: item.reports,
      priority: item.priority,
      verified: item.verified,
      color: item.ghostFlag ? "#ff4db8" : "#5fcdff",
      accent: item.ghostFlag ? "coral" : "blue",
    }));
    const ids = new Set(persisted.map((item) => item.id));
    return [...persisted, ...incidents.filter((item) => !ids.has(item.id))];
  }, [liveQuery.data]);

  const visibleIncidents = useMemo(() => allIncidents.filter((incident) => {
    const matchesFilter = filter === "All" || incident.status === filter;
    const term = query.trim().toLowerCase();
    const matchesQuery = !term || `${incident.title} ${incident.location} ${incident.category}`.toLowerCase().includes(term);
    const matchesCategory = categoryFilter === "All categories" || incident.category === categoryFilter;
    return matchesFilter && matchesQuery && matchesCategory;
  }), [allIncidents, filter, query, categoryFilter]);

  const selected = allIncidents.find((incident) => incident.id === selectedId) ?? allIncidents[0];
  const displayTimeline = useMemo(() => {
    const persisted = selectedDetailQuery.data?.timeline ?? [];
    if (!persisted.length) return timeline;
    return persisted.map((item) => ({
      time: new Date(item.createdAt).toLocaleString(),
      icon: item.eventType === "reported" ? MessageSquareWarning : item.eventType === "proof_submitted" ? FileCheck2 : item.eventType === "resolution_challenged" ? Flag : Blocks,
      title: item.title,
      body: item.description,
      tone: item.eventType === "resolution_challenged" ? "coral" : item.eventType === "proof_submitted" ? "mint" : "blue",
    }));
  }, [selectedDetailQuery.data]);

  useEffect(() => {
    const exitTimer = window.setTimeout(() => setIntroStage("exit"), 1450);
    const readyTimer = window.setTimeout(() => setPageReady(true), 1900);
    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(readyTimer);
    };
  }, []);

  const handleChallenge = () => {
    challengeMutation.mutate({ civicId: selected.id, challengerKey: reporterKey, reason: "The issue is still visible at the reported location." });
  };

  const handleReport = () => {
    createComplaintMutation.mutate({ reporterKey, title: `${reportCategory} reported near ${reportLocation}`, category: reportCategory, description: reportDescription, location: reportLocation, priority: reportCategory === "Safety" ? 90 : 70 });
  };
  const handleProof = () => {
    proofMutation.mutate({ civicId: selected.id, submittedBy: reporterKey, beforeUrl: "/manus-storage/civic-ledger-city_cb743e13.jpg", afterUrl: "/manus-storage/civic-ledger-city_cb743e13.jpg", qualityScore: 92 });
  };

  return (
    <div className={`app-shell ${pageReady ? "page-ready" : "page-loading"}`}>
      {!pageReady && <div className={`intro-sequence intro-${introStage}`} aria-label="Loading trUSt-me-humans">
        <div className="intro-orbit orbit-one" /><div className="intro-orbit orbit-two" />
        <div className="intro-center"><div className={`intro-logo intro-3d-logo ${introStage === "exit" ? "intro-logo-exit" : ""}`}><img src="/manus-storage/pasted_file_8Hjo02_image_22619dcd.png" alt="Joined hands logo" /></div><div className="intro-wordmark">trUSt-me-humans</div></div>
      </div>}
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <div className="brand-lockup"><div className="brand-mark"><img src="/manus-storage/pasted_file_8Hjo02_image_22619dcd.png" alt="Joined hands logo" /></div><div><div className="brand-name">trUSt-me-humans</div><div className="brand-caption">PUBLIC TRUST INFRASTRUCTURE</div></div></div>
        <div className="workspace-switcher"><span className="workspace-dot" /> New Delhi pilot <ChevronDown size={14} /></div>
        <div className="rail-label">OVERVIEW</div>
        <nav className="rail-nav">
          {[[LayoutDashboard, "Command center"], [MapPinned, "Civic heatmap"], [FileCheck2, "My complaints"], [BarChart3, "Trust score"]].map(([Icon, label]) => <button key={label as string} className={`rail-item ${activeNav === label ? "active" : ""}`} onClick={() => { setActiveNav(label as string); setMobileOpen(false); }}><Icon size={17} /><span>{label as string}</span>{label === "Civic heatmap" && <span className="rail-count">24</span>}</button>)}
        </nav>
        <div className="rail-label rail-label-spaced">LEDGER</div>
        <nav className="rail-nav">
          <button className={`rail-item ${activeNav === "Audit trail" ? "active" : ""}`} onClick={() => { setActiveNav("Audit trail"); setMobileOpen(false); }}><Blocks size={17} /><span>Audit trail</span><span className="live-pulse" /></button>
          <button className="rail-item" onClick={() => toast.info("Verifier network", { description: "Nearby citizen verification weights are active." })}><UsersRound size={17} /><span>Verifier network</span></button>
        </nav>
        <div className="sidebar-bottom"><button className="network-card network-card-button" onClick={() => setActiveNav("Network status")}><div className="network-header"><span>NETWORK STATUS</span><span className="online"><span /> ONLINE</span></div><div className="network-main"><Radio size={17} /><span>Sepolia testnet</span><CheckCircle2 size={15} /></div><div className="network-hash">Block #18,492,881 · 12s ago</div></button><div className="profile-row"><div className="avatar">{profileInitials}</div><div><div className="profile-name">{profileName}</div><div className="profile-meta">{isAuthenticated ? (user?.email ?? "Signed in with Gmail") : "Browsing privately"}</div></div><MoreHorizontal size={17} className="profile-more" /></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMobileOpen((open) => !open)}><Menu size={20} /></button><div className="breadcrumb"><span>Workspace</span><span>/</span><strong>{activeNav}</strong></div><div className="topbar-actions"><div className="sync-status"><span className="sync-dot" /> Ledger synced <span className="sync-time">12s</span></div><button className="icon-button" onClick={() => toast.info("No new alerts", { description: "Your watchlist is all clear for now." })}><Bell size={18} /><span className="notification-badge">3</span></button><button className="top-avatar" onClick={() => setShowLogin(!isAuthenticated)}>{profileInitials}</button></div></header>

        <section className="hero-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> 13 SEPTEMBER 2026 · LIVE CIVIC PULSE</div><h1>Track every rupee.<br /><em>Track every promise.</em></h1><p className="hero-copy">Track every project, every public commitment, and every proof point — in one human-readable civic record.</p></div><div className="hero-actions"><button className="button button-primary" onClick={() => setShowReport(true)}><Plus size={17} /> Report an issue</button><button className="button button-ghost" onClick={() => toast.info("Sharing view link", { description: "A read-only command center link has been copied." })}><ArrowUpRight size={16} /> Share view</button></div></section>

        <section className="metric-grid"><MetricCard label="Open incidents" value="24" delta="6% from last week" icon={AlertTriangle} tone="coral" /><MetricCard label="Proof-backed fixes" value="82%" delta="14% above city avg." icon={ShieldCheck} tone="mint" /><MetricCard label="Avg. response time" value="3h 18m" delta="46m faster this month" icon={Timer} tone="blue" /><MetricCard label="Civic trust score" value="82 / 100" delta="+4.8 points this quarter" icon={Gauge} tone="amber" /></section>

        <section className="workspace-grid">
          <div className="map-card panel-card">
            <div className="panel-heading"><div><div className="section-kicker"><Crosshair size={13} /> LIVE HEATMAP</div><h2>India civic pulse · every city on record</h2></div><div className="map-tools"><select value={filter} onChange={(event) => setFilter(event.target.value as "All" | Status)} aria-label="Filter heatmap status">{statusOptions.map((option) => <option key={option}>{option}</option>)}</select><button className="small-icon-button" onClick={() => { setFilter("All"); setQuery(""); }}><RotateCcw size={15} /></button></div></div>
            <div className="map-visual live-google-map-visual"><MapView initialCenter={{ lat: 22.5, lng: 79.0 }} initialZoom={5} className="live-google-map" onMapReady={(map) => { hotspots.forEach((spot) => new google.maps.Circle({ map, center: { lat: spot.lat, lng: spot.lng }, radius: spot.reports * 900, fillColor: spot.tone === "critical" ? "#ff4db8" : spot.tone === "hot" ? "#ff8c69" : "#7185ff", fillOpacity: spot.tone === "critical" ? .34 : .2, strokeColor: spot.tone === "critical" ? "#ff4db8" : "#5fcdff", strokeOpacity: .8, strokeWeight: 1 })) }} /><div className="map-label map-label-top">INDIA · LIVE</div><div className="map-label map-label-right">6 STATES</div>{hotspots.map((spot) => <button key={spot.city} className={`map-pin live-hotspot-pin pin-${spot.tone}`} style={{ left: spot.left, top: spot.top }} onClick={() => setSelectedHotspot(spot)} aria-label={`Open ${spot.city} hotspot`}><span className="pin-core" /><span className="pin-ring" /><span className="live-hotspot-count">{spot.reports}</span></button>)}<div className="map-you"><span className="you-ring" /><span className="you-dot" /> YOU</div><div className="map-legend"><span><i className="legend-dot coral" /> Critical</span><span><i className="legend-dot amber" /> High</span><span><i className="legend-dot mint" /> Medium</span></div></div>
            <div className="map-footer"><span><span className="foot-dot" /> 24 live incidents across 8 wards</span><button onClick={() => setShowFullMap(true)}>Open full map <ArrowUpRight size={14} /></button></div>
          </div>

          <div className="incident-card panel-card"><div className="panel-heading incident-heading"><div><div className="section-kicker"><ListFilter size={13} /> PRIORITY QUEUE</div><h2>Incidents to watch</h2></div><button className="text-button" onClick={() => setFilter("All")}>View all <ArrowUpRight size={14} /></button></div><div className="incident-toolbar"><div className="search-box"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search incidents" /></div><select className="filter-select" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} aria-label="Filter by category"><option>All categories</option><option>Roads</option><option>Lighting</option><option>Sanitation</option><option>Water</option><option>Safety</option></select></div><div className="incident-list">{visibleIncidents.slice(0, 4).map((incident) => <button key={incident.id} className={`incident-row ${selected.id === incident.id ? "selected" : ""}`} onClick={() => setSelectedId(incident.id)}><div className="incident-accent" style={{ background: incident.color }} /><div className="incident-row-main"><div className="incident-row-top"><span className="incident-category">{incident.category} · {incident.id}</span><StatusPill status={incident.status} /></div><div className="incident-title">{incident.title}</div><div className="incident-location"><MapPinned size={12} /> {incident.location} <span>·</span> {incident.age}</div></div><div className="incident-score"><span>PRIORITY</span><strong>{incident.priority}</strong></div></button>)}{visibleIncidents.length === 0 && <div className="empty-state"><Search size={18} />No incidents match that filter.</div>}</div><div className="queue-footer"><span><Sparkles size={14} /> Sorted by community impact</span><span className="queue-count">{visibleIncidents.length} shown · {ghostQuery.data?.length ?? 0} ghost alerts</span></div></div>
        </section>

        <section className="lower-grid">
          <div className="detail-card panel-card"><div className="detail-cover"><img src="/manus-storage/civic-ledger-city_cb743e13.jpg" alt="Road crew repairing a city street after rain" /><div className="cover-overlay" /><div className="cover-chip"><span className="live-pulse" /> SELECTED INCIDENT</div><div className="cover-title"><span>{selected.category} · {selected.id}</span><h2>{selected.title}</h2><p><MapPinned size={14} /> {selected.location}</p></div></div><div className="detail-body"><div className="detail-status-row"><StatusPill status={selected.status} />{(selectedDetailQuery.data?.complaint.ghostFlag ?? 0) > 0 && <span className="ghost-badge"><AlertTriangle size={12} /> GHOST PATTERN</span>}<span className="detail-updated"><Clock3 size={13} /> Updated 4 min ago</span><button className="small-icon-button"><MoreHorizontal size={16} /></button></div><div className="proof-strip"><div className="proof-score"><div className="score-ring" style={{ "--score": `${selected.priority}%` } as React.CSSProperties}><strong>{selected.priority}</strong><span>/100</span></div><div><b>Impact priority</b><small>Weighted by urgency, reports & location</small></div></div><div className="proof-meta"><div><span>REPORTS</span><b>{selected.reports}</b></div><div><span>VERIFIED</span><b>{selected.verified}</b></div><div><span>SLA</span><b className="sla-good">ON TRACK</b></div></div></div><div className="detail-actions"><button className="button button-primary compact" onClick={handleChallenge}><Flag size={15} /> {challengeSent ? "Challenge recorded" : "Challenge resolution"}</button><button className="button button-ghost compact" onClick={handleProof}><FileCheck2 size={15} /> Anchor proof-of-resolution</button></div></div></div>

          <div className="timeline-card panel-card"><div className="panel-heading"><div><div className="section-kicker"><GitBranch size={13} /> IMMUTABLE TIMELINE</div><h2>Nothing gets overwritten.</h2></div><button className="small-icon-button" onClick={() => toast.info("Audit trail copied", { description: "A public, read-only record link is ready." })}><ArrowUpRight size={15} /></button></div><div className="timeline">{displayTimeline.map((item) => { const Icon = item.icon; return <div className="timeline-item" key={item.time}><div className={`timeline-icon ${item.tone}`}><Icon size={14} /></div><div className="timeline-content"><div className="timeline-meta">{item.time}<span className="timeline-verified"><Check size={11} /> VERIFIED</span></div><div className="timeline-title">{item.title}</div><div className="timeline-body">{item.body}</div></div></div>; })}</div><div className="hash-row"><Blocks size={14} /><span>Last anchor <b>0x8f4c…92a</b></span><span className="hash-check"><CheckCircle2 size={14} /> Tamper-evident</span></div></div>
        </section>

        <footer className="page-footer"><span><ShieldCheck size={14} /> Personal data is kept private. Proof is public.</span><span>Built for communities that verify.</span></footer>
      </main>

      {activeNav === "Civic heatmap" && <div className="modal-backdrop feature-backdrop" onClick={() => setActiveNav("Command center")}><div className="feature-sheet heatmap-feature" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><MapPinned size={13} /> CIVIC HEATMAP</div><h2>India · state-level civic pulse</h2></div><button className="small-icon-button" onClick={() => setActiveNav("Command center")}><X size={16} /></button></div><p className="modal-copy">A live-style demonstration layer using realistic sample reports across Indian states and cities. Pan and zoom the map to explore the country.</p><div className="heatmap-feature-map"><MapView initialCenter={{ lat: 22.5, lng: 79.0 }} initialZoom={5} className="feature-google-map" onMapReady={(map) => { hotspots.forEach((spot) => new google.maps.Circle({ map, center: { lat: spot.lat, lng: spot.lng }, radius: spot.reports * 900, fillColor: spot.tone === "critical" ? "#ff4db8" : spot.tone === "hot" ? "#ff8c69" : "#7b8cff", fillOpacity: spot.tone === "critical" ? .38 : .25, strokeColor: spot.tone === "critical" ? "#ff4db8" : "#5fcdff", strokeOpacity: .8, strokeWeight: 1 })) }} />{hotspots.map((spot) => <button key={spot.city} className={`hotspot-button hotspot-${spot.tone}`} style={{ left: spot.left, top: spot.top }} onClick={() => setSelectedHotspot(spot)} aria-label={`View ${spot.city} hotspot`}><span /><b>{spot.reports}</b></button>)}<div className="map-state-label state-north">NORTH</div><div className="map-state-label state-west">WEST</div><div className="map-state-label state-south">SOUTH</div><div className="map-state-label state-east">EAST</div></div><div className="heatmap-bottom"><div className="heat-legend"><b>HOTSPOT INTENSITY</b><span><i className="heat-low" /> 1–25</span><span><i className="heat-mid" /> 26–50</span><span><i className="heat-high" /> 51+ reports</span></div><div className="hotspot-detail"><div className="section-kicker">SELECTED HOTSPOT</div><h3>{selectedHotspot.city}, {selectedHotspot.state}</h3><p>{selectedHotspot.category} · {selectedHotspot.reports} reports · <strong>{selectedHotspot.severity}</strong> severity</p><StatusPill status={selectedHotspot.status} /></div></div></div></div>}
      {activeNav === "Trust score" && <div className="modal-backdrop feature-backdrop" onClick={() => setActiveNav("Command center")}><div className="feature-sheet trust-feature" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><Gauge size={13} /> TRUST SCORE</div><h2>How public confidence is built</h2></div><button className="small-icon-button" onClick={() => setActiveNav("Command center")}><X size={16} /></button></div><div className="trust-feature-top"><div className="large-score-ring"><strong>82</strong><span>/100</span></div><div><h3>Strong civic confidence</h3><p>Up 4.8 points this quarter, driven by verified fixes and transparent evidence.</p><div className="trust-meter"><span style={{ width: "82%" }} /></div></div></div><div className="trust-factor-list">{trustFactors.map(([label, score, detail]) => <div className="trust-factor" key={label}><div><b>{label}</b><small>{detail}</small></div><strong>{score}<span>/20</span></strong><div className="factor-bar"><span style={{ width: `${score * 5}%` }} /></div></div>)}</div><div className="trust-footnote"><ShieldCheck size={15} /> Score is a demo calculation using verified Indian civic records; it is not a government rating.</div></div></div>}
      {activeNav === "Audit trail" && <div className="modal-backdrop feature-backdrop" onClick={() => setActiveNav("Command center")}><div className="feature-sheet audit-feature" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><Blocks size={13} /> AUDIT TRAIL</div><h2>Every action, in order</h2></div><button className="small-icon-button" onClick={() => setActiveNav("Command center")}><X size={16} /></button></div><p className="modal-copy">A chronological, read-only activity record for CIV-82914. Each event includes the responsible role and current verification state.</p><div className="audit-timeline">{auditEvents.map(([time, title, actor, status], index) => <div className="audit-event" key={title}><div className="audit-marker">{index + 1}</div><div className="audit-event-main"><div className="audit-event-top"><strong>{title}</strong><span>{time} · {status}</span></div><p>{actor}</p></div></div>)}</div><button className="button button-ghost full" onClick={() => toast.success("Audit trail ready", { description: "A read-only share link is available for this demonstration." })}><ArrowUpRight size={15} /> Share read-only audit trail</button></div></div>}
      {activeNav === "Network status" && <div className="modal-backdrop feature-backdrop" onClick={() => setActiveNav("Command center")}><div className="feature-sheet network-feature" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><Radio size={13} /> NETWORK STATUS · DEMO MONITOR</div><h2>System health at a glance</h2></div><button className="small-icon-button" onClick={() => setActiveNav("Command center")}><X size={16} /></button></div><div className="network-summary"><span className="network-status-dot" /> ONLINE <small>Last updated just now</small></div><div className="network-service-list">{networkServices.map(([label, status, detail]) => <div className="network-service" key={label}><div className="service-status"><span className="service-dot" />{status}</div><div><b>{label}</b><small>{detail}</small></div><CheckCircle2 size={17} /></div>)}</div><div className="network-demo-note"><Info size={15} /><span><b>Clearly labelled demo monitor.</b> These indicators are prototype status signals for the SIH demonstration and do not claim to monitor production infrastructure.</span></div></div></div>}
      {activeNav === "My complaints" && <div className="modal-backdrop issues-backdrop" onClick={() => setActiveNav("Command center")}><div className="issues-sheet" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><FileCheck2 size={13} /> MY COMPLAINTS</div><h2>Your civic receipts</h2></div><button className="small-icon-button" onClick={() => setActiveNav("Command center")}><X size={16} /></button></div><p className="modal-copy">Reports from this browser are linked by a private reporter key and remain visible as the ledger changes.</p><div className="my-issues-list">{mineQuery.isLoading && <div className="empty-state">Loading your receipts…</div>}{!mineQuery.isLoading && !(mineQuery.data?.length) && <div className="empty-state"><FileCheck2 size={18} />No complaints reported from this browser yet.</div>}{mineQuery.data?.map((item) => <button className="my-issue-row" key={item.civicId} onClick={() => { setSelectedId(item.civicId); setActiveNav("Command center"); }}><div><strong>{item.title}</strong><span>{item.civicId} · {item.location}</span></div><StatusPill status={item.status as Status} /></button>)}</div></div></div>}
      {showFullMap && <div className="modal-backdrop" onClick={() => setShowFullMap(false)}><div className="full-map-modal" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><MapPinned size={13} /> INDIA CIVIC MAP</div><h2>Every city. One public record.</h2></div><button className="small-icon-button" onClick={() => setShowFullMap(false)}><X size={16} /></button></div><div className="india-map google-india-map"><MapView initialCenter={{ lat: 22.5, lng: 79.0 }} initialZoom={5} className="google-map-view" onMapReady={(map) => { new google.maps.TrafficLayer().setMap(map); }} /><div className="map-overlay-title">INDIA · LIVE CIVIC PULSE</div><div className="city-chip city-chip-delhi">Delhi <b>7</b></div><div className="city-chip city-chip-mumbai">Mumbai <b>4</b></div><div className="city-chip city-chip-kolkata">Kolkata <b>3</b></div><div className="city-chip city-chip-bengaluru">Bengaluru <b>5</b></div><div className="city-chip city-chip-chennai">Chennai <b>2</b></div><div className="city-chip city-chip-hyderabad">Hyderabad <b>3</b></div></div><div className="city-list"><span><i />24 active incidents</span><span><i />8 wards in review</span><span><i />11 verified city clusters</span></div></div></div>}{showLogin && <div className="modal-backdrop" onClick={() => setShowLogin(false)}><div className="login-modal" onClick={(event) => event.stopPropagation()}><div className="login-logo"><img src="/manus-storage/pasted_file_8Hjo02_image_22619dcd.png" alt="trUSt-me-humans" /></div><h2>Sign in to trUSt-me-humans</h2><p>Keep your reports, receipts, and verification history in one place.</p><button className="google-button" onClick={startLogin}><span className="google-g">G</span> Continue with Google / Gmail</button><button className="login-secondary" onClick={() => setShowLogin(false)}>Continue as guest</button></div></div>}{showReport && <div className="modal-backdrop" onClick={() => setShowReport(false)}><div className="report-modal" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><div className="section-kicker"><Plus size={13} /> NEW CIVIC RECEIPT</div><h2>Report an issue</h2></div><button className="small-icon-button" onClick={() => setShowReport(false)}><X size={16} /></button></div><p className="modal-copy">Create a permanent, private-by-default record. We’ll anchor the evidence and route it to the right ward.</p><label>What needs attention?<select value={reportCategory} onChange={(event) => setReportCategory(event.target.value)}><option value="Roads">Pothole / road damage</option><option value="Lighting">Streetlight outage</option><option value="Water">Water leak</option><option value="Sanitation">Overflowing bins</option><option value="Other">Other civic issue</option><option value="Safety">Unsafe road / crossing</option></select></label><label>Where is it?<div className="input-with-icon"><MapPinned size={15} /><input value={reportLocation} onChange={(event) => setReportLocation(event.target.value)} /></div></label><label>Add a photo or evidence<input className="file-input" type="file" accept="image/*" onChange={(event) => setImageName(event.target.files?.[0]?.name ?? "")} />{imageName && <span className="file-name">{imageName}</span>}</label><label>Short description<textarea value={reportDescription} onChange={(event) => setReportDescription(event.target.value)} /></label><div className="privacy-note"><ShieldCheck size={16} /><span><b>Private by default</b>Your identity stays off-chain. Only the proof of place and time becomes public.</span></div><button className="button button-primary full" onClick={handleReport}><Zap size={16} /> Create civic receipt</button></div></div>}
    </div>
  );
}
