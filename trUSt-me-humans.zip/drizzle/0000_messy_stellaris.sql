CREATE TABLE `complaints` (
	`id` int AUTO_INCREMENT NOT NULL,
	`civicId` varchar(32) NOT NULL,
	`reporterKey` varchar(128) NOT NULL,
	`title` varchar(180) NOT NULL,
	`category` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`location` varchar(255) NOT NULL,
	`status` enum('Open','Under review','Resolved','Disputed','Reopened') NOT NULL DEFAULT 'Open',
	`priority` int NOT NULL DEFAULT 50,
	`reports` int NOT NULL DEFAULT 1,
	`verified` int NOT NULL DEFAULT 0,
	`resolutionCount` int NOT NULL DEFAULT 0,
	`reopenCount` int NOT NULL DEFAULT 0,
	`ghostFlag` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `complaints_id` PRIMARY KEY(`id`),
	CONSTRAINT `complaints_civicId_unique` UNIQUE(`civicId`)
);
--> statement-breakpoint
CREATE TABLE `proof_packages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`complaintId` int NOT NULL,
	`beforeUrl` varchar(500),
	`afterUrl` varchar(500),
	`evidenceHash` varchar(128) NOT NULL,
	`qualityScore` int NOT NULL DEFAULT 0,
	`locationVerified` int NOT NULL DEFAULT 0,
	`timestampVerified` int NOT NULL DEFAULT 0,
	`citizenVerifications` int NOT NULL DEFAULT 0,
	`submittedBy` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `proof_packages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `resolution_challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`complaintId` int NOT NULL,
	`challengerKey` varchar(128) NOT NULL,
	`reason` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `resolution_challenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `timeline_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`complaintId` int NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`actorLabel` varchar(128) NOT NULL,
	`eventHash` varchar(128) NOT NULL,
	`previousHash` varchar(128),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `timeline_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
