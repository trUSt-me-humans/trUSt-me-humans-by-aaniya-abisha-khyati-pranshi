import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const complaints = mysqlTable("complaints", {
  id: int("id").autoincrement().primaryKey(),
  civicId: varchar("civicId", { length: 32 }).notNull().unique(),
  reporterKey: varchar("reporterKey", { length: 128 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["Open", "Under review", "Resolved", "Disputed", "Reopened"]).default("Open").notNull(),
  priority: int("priority").default(50).notNull(),
  reports: int("reports").default(1).notNull(),
  verified: int("verified").default(0).notNull(),
  resolutionCount: int("resolutionCount").default(0).notNull(),
  reopenCount: int("reopenCount").default(0).notNull(),
  ghostFlag: int("ghostFlag").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const timelineEvents = mysqlTable("timeline_events", {
  id: int("id").autoincrement().primaryKey(),
  complaintId: int("complaintId").notNull(),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  actorLabel: varchar("actorLabel", { length: 128 }).notNull(),
  eventHash: varchar("eventHash", { length: 128 }).notNull(),
  previousHash: varchar("previousHash", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const proofPackages = mysqlTable("proof_packages", {
  id: int("id").autoincrement().primaryKey(),
  complaintId: int("complaintId").notNull(),
  beforeUrl: varchar("beforeUrl", { length: 500 }),
  afterUrl: varchar("afterUrl", { length: 500 }),
  evidenceHash: varchar("evidenceHash", { length: 128 }).notNull(),
  qualityScore: int("qualityScore").default(0).notNull(),
  locationVerified: int("locationVerified").default(0).notNull(),
  timestampVerified: int("timestampVerified").default(0).notNull(),
  citizenVerifications: int("citizenVerifications").default(0).notNull(),
  submittedBy: varchar("submittedBy", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const resolutionChallenges = mysqlTable("resolution_challenges", {
  id: int("id").autoincrement().primaryKey(),
  complaintId: int("complaintId").notNull(),
  challengerKey: varchar("challengerKey", { length: 128 }).notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Complaint = typeof complaints.$inferSelect;
export type TimelineEvent = typeof timelineEvents.$inferSelect;
export type ProofPackage = typeof proofPackages.$inferSelect;
export type ResolutionChallenge = typeof resolutionChallenges.$inferSelect;
